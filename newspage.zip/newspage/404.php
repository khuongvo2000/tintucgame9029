<?php

// Kết nối database 
require 'core/init.php';

// Header
require 'includes/header.php';

// Content
require 'templates/404.php';

// Footer
require 'includes/footer.php';

?>